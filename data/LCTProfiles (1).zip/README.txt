The MS Excel files contain 100 different daily (24 hours) profiles with 5-min resolution.
- Each column (100 in total) corresponds to one different profile
- Each line (288 in total) corresponds to a 5-min value

More info about the profiles: https://www.researchgate.net/publication/283569482_Dissemination_Document_Low_Voltage_Networks_Models_and_Low_Carbon_Technology_Profiles

Enjoy! And share the knowledge!